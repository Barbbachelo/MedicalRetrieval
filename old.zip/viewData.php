<HTML XMLns="http://www.w3.org/1999/xHTML"> 
<head> 
 	<link rel="stylesheet" type="text/css" href="forms.css">
 	<link rel="stylesheet" type="text/css" href="viewStyle.css">
    <script src="script.js"></script>
    <title>View Data</title> 
 </head>
 <html>
 	<body>
        <div id="header"> 
			<h1>View Data</h1>
			<a href="login.php" class="close">Log Out</a>
        </div>
      <div align="center" id='form'>
        <form >
            <label>First Name:</label>		
			<input type="text" name="fName" class="field-long">

            <label>Last Name:</label>		
			<input type="text" name="lName" class="field-long"> </label> 

            <label>Patient ID:</label>		
			<input type="text" name="PID" class="field-long"> </label> 

            <label>Gender:</label>		
			<input type="text" name="gender" class="field-long"> </label> 

            <label>D.O.B:</label>		
			<input type="text" name="DOB" class="field-long"> </label> 

            <label>Child ID:</label>	
			<input type="text" name="CID" class="field-long"> </label> <br>

            <input type="submit" value="Search" name="submit" />
		</form>
  </div>
</body>
  <?php
if (isset($_GET['submit']))
 {
	if (isset($_GET['fName']))
	{
		$fName = $_GET['fName'];
	}
	
	//SQL Queries
	$connection = mysqli_connect("127.0.0.1", "root", "", "patients");
	$searchQuery = "Select * from patients Where fName = '$fName';";
	$search = mysqli_query($connection, $searchQuery);
	$row_count = mysqli_num_rows($search);
	if ($row_count == 0)
	{
		echo 'Patient does not exist  <br/>';
	}
	else
	{
	echo "<table id='menu'>";
	echo "<tr>
	<th>First Name</th>
	<th>Last Name</th>
	<th>Patient ID</th>
	<th>Gender</th>
	<th>D.O.B</th>
	<th>CID</th>
	</tr>";
	$row = mysqli_fetch_row($search);
	while ($row) 
	{
		echo "<tr><td>{$row[0]}</td>";
		echo "<td>{$row[1]}</td>";
		echo "<td>{$row[2]}</td>";
		echo "<td>{$row[3]}</td>";
		echo "<td>{$row[4]}</td>";
		echo "<td>{$row[5]}</td>";
		$row = mysqli_fetch_row($search);
	}
	echo "</table>";	
	
	mysqli_free_result($search);
	mysqli_close($connection);
	}
 }
?>
</html>