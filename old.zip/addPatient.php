<HTML XMLns="http://www.w3.org/1999/xHTML"> 
<head> 
 	<link rel="stylesheet" type="text/css" href="forms.css">
    <link rel="stylesheet" type="text/css" href="addStyle.css">
    <script src="script.js"></script>
    <title>Add Patient</title> 
 </head>
 <html>
 	<body>
        <div id="header"> 
			<h1>Add Patient</h1>
			<a href="login.php" class="close">Log Out</a>
        </div>
			<div class="div"/>
            <form> 
              <ul class="form-style-1">
                <li>
                    <label>Full Name <span class="required">*</span></label><input type="text" name="fname" class="field-divided" placeholder="First" />&nbsp;
                    <input type="text" name="lname" class="field-divided" placeholder="Last" />
                </li>
                <li>
					<label>Gender <span class="required">*</span></label>
                    <input type="text" name="gender" class="field-long" />
                </li>
                <li>
					<label>Child ID <span class="required">*</span></label>
                	<input type="text" name="cid" class="field-long" />
                </li>
                <li>
					<label>Post Code <span class="required">*</span></label>
                    <input type="text" name="pcode" class="field-long" />
                 </li>
                <li>
					<label>Date of Birth <span class="required">*</span></label>
                    <input type="text" name="dob" class="field-long" placeholder="DD/MM/YYYY"/>
                 </li> 
                <li>
					<label>ICD<span class="required">*</span></label>
                    <input type="text" name="icd" class="field-long" placeholder="Seperate ICDs with a comma"  />
                 </li>     
				 <li>
					<label>Comments</label>
					<textarea name="comments" class="field-textarea" rows="1" >Enter comments here...</textarea>
		
                 <li>
                     <input type="submit" value="Add Patient" name="submit" />
                 </li>

              </ul>
          </form>
	 </div>
</body>
</html>

<?php
if (isset($_GET['submit']))
 {
  $fName = $_GET['fname'];
  $lName = $_GET['lname'];
  $Gender = $_GET['gender'];
  $pCode = $_GET['pcode'];
  $DOB = $_GET['dob'];
  $CID = $_GET['cid'];
  $ICD = $_GET['icd'];
  $Comments = $_GET['comments'];
  
  $dobReversed = strrev($DOB);
		
		
  $connection = mysqli_connect("127.0.0.1", "root", "", "medicalretrieval");
  $SQLstring = "INSERT INTO patients(FName, LName, Gender, DOB, PostCode, CID, siblingID, ICD, Comments, Extra) VALUES ('$fName', '$lName', '$Gender', '$dobReversed','$pCode', '$CID', '' , '$ICD', '$Comments', '');";
  mysqli_query($connection, $SQLstring);
 }
?>