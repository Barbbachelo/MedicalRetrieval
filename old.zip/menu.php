<HTML XMLns="http://www.w3.org/1999/xHTML"> 
<head> 
 	<link rel="stylesheet" type="text/css" href="style.css">
    <script src="script.js"></script>
    <title>Main Menu</title> 
 </head>
 <html>
 	<body>
	        <div id="header"> 
			<h1>Menu</h1>
			<a href="login.php" class="close">Log Out</a>
        </div>
		<br>
   	<div id="menu" align="center">
      <h2><a href="addPatient.php">Add Patient</a></h2>
      <h2><a href="viewData.php">View Data</a></h2>
   	</div>
</body>
 </html>
