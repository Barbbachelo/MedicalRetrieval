// JavaScript Document
function addMouseOver() {
    document.getElementById("add").src="images/addclicked.png"
}

function addMouseOut() {
    document.getElementById("add").src="images/addpatient.png"
}

/*function confirmFunction() 
{
  var cid = document.getElementsByName("cid")[0].value;
  var fname = document.getElementsByName("fname")[0].value;
  var lname = document.getElementsByName("lname")[0].value;
  var dob = document.getElementsByName("dob")[0].value;
  var pcode = document.getElementsByName("pcode")[0].value;
  var gender = document.getElementsByName("gender")[0].value;
  var icd = document.getElementsByName("icd")[0].value;
  
  var x = "CONFIRMATION:" + " \n \n";
  x += "Child ID: " + cid + "\n";
  x += "First name: " + fname + "\n";
  x += "Last name: " + lname + "\n";
  x += "Date of Birth: " + dob + "\n";
  x += "Postcode: " + pcode + "\n";
  x += "Gender: " + gender + "\n";
  x += "ICD: " + icd + "\n";
  
  
  if (confirm(x) == true)
  {
	  
  }
  else
  {
  
  }

}*/